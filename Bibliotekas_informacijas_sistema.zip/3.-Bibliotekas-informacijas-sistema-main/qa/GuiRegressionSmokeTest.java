import bibliotekas_informacijas_sistema.model.Lietotajs;
import bibliotekas_informacijas_sistema.model.Loma;
import java.awt.Container;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.text.MaskFormatter;

/** GUI smoke tests: run with a graphical desktop (or xvfb-run on Linux). */
public final class GuiRegressionSmokeTest {
    private static int checks;

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        checks++;
    }
    private static Object get(Object target, String name) throws Exception {
        Field field = target.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(target);
    }
    private static void set(Object target, String name, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(name);
        field.setAccessible(true);
        field.set(target, value);
    }
    private static void invoke(Object target, String name) throws Exception {
        Method m = target.getClass().getDeclaredMethod(name);
        m.setAccessible(true);
        m.invoke(target);
    }
    private static JDialog dialog(Object target, String field) throws Exception {
        return (JDialog) get(target, field);
    }
    private static JMenu menu(Object target, String field) throws Exception {
        return (JMenu) get(target, field);
    }
    private static boolean visible(Object target, String field) throws Exception {
        return dialog(target, field).isVisible();
    }
    private static void close(Object target, String name) throws Exception {
        JDialog d = dialog(target, name);
        d.dispatchEvent(new WindowEvent(d, WindowEvent.WINDOW_CLOSING));
    }
    private static Lietotajs user(Loma role) {
        Lietotajs user = new Lietotajs();
        user.setLietotajaId(1);
        user.setVards("GUI");
        user.setUzvards("Pārbaude");
        user.setLoma(role);
        return user;
    }
    public static void main(String[] args) throws Exception {
        try {
            SwingUtilities.invokeAndWait(() -> {
                LibInfoSaskarne app = null;
                try {
                    app = new LibInfoSaskarne();
                    check(visible(app,"LoginDialog"), "Log in opens at startup");
                    for (String name : new String[] {"LoginDialog","RegisterDialog","MainDialog",
                            "BookListDialog","BookEditDialog","UserListDialog","UserEditDialog",
                            "LoanDialog","ReturnDialog","ReservationDialog","NotificationDialog"}) {
                        JDialog d = dialog(app,name);
                        check(!d.isModal(), "Nonmodal: "+name);
                        check(d.getDefaultCloseOperation()==WindowConstants.HIDE_ON_CLOSE, "Close policy: "+name);
                        check(d.getWindowListeners().length>=2, "Closing event exists: "+name);
                        check(d.getWidth()>100 && d.getHeight()>100, "Packed: "+name);
                    }
                    int[] counts = {1,3,2,3,1,1,1};
                    String[] menuNames = {"FileMenu","BookMenu","UserMenu","LoanMenu",
                            "ReservationMenu","NotificationMenu","HelpMenu"};
                    for (int i=0;i<menuNames.length;i++) {
                        JMenu menu=menu(app,menuNames[i]);
                        check(menu.getItemCount()==counts[i],"Menu count: "+menuNames[i]);
                        for (int j=0;j<menu.getItemCount();j++)
                            check(menu.getItem(j).getActionListeners().length==1,
                                    "Menu handler: "+menuNames[i]+"/"+j);
                    }
                    JSpinner spinner=(JSpinner)get(app,"BookYearSpinner");
                    SpinnerNumberModel model=(SpinnerNumberModel)spinner.getModel();
                    check(model.getMinimum().equals(1800),"Year minimum");
                    check(model.getMaximum().equals(LocalDate.now().getYear()+1),"Year maximum");
                    check(!((JTextField)get(app,"LoanDateTextField")).isEditable(),"Loan date readonly");
                    JFormattedTextField due=(JFormattedTextField)get(app,"LoanTimeFormattedTextField");
                    check(due.getFormatter() instanceof MaskFormatter,"Loan date mask");
                    JTable reservation=(JTable)get(app,"ReservationTable");
                    check(((DefaultListSelectionModel)reservation.getSelectionModel()).getListSelectionListeners().length>0,"Reservation selection events");
                    for (String name:new String[]{"BookTable","UserTable","ReturnTable",
                            "ReservationTable","NotificationTable"}) {
                        JTable table=(JTable)get(app,name);
                        check(table.getRowHeight()==26,"Row height: "+name);
                        check(table.getAutoCreateRowSorter(),"Sorter: "+name);
                        check(!table.getTableHeader().getReorderingAllowed(),"Header stable: "+name);
                    }
                    // User access rights must be unchanged by migrating JMenuItems into .form.
                    set(app,"currentUser",user(Loma.READER));
                    invoke(app,"showMain");
                    check(!menu(app,"UserMenu").isEnabled(),"Reader cannot manage users");
                    check(!menu(app,"LoanMenu").isEnabled(),"Reader cannot issue books");
                    check(!((JMenuItem)get(app,"menuAddBookItem")).isEnabled(),"Reader cannot add books");
                    check(menu(app,"ReservationMenu").isEnabled(),"Reader can reserve books");
                    menu(app,"BookMenu").getItem(0).doClick();
                    check(visible(app,"BookListDialog"),"Book list menu opens books");
                    close(app,"BookListDialog");
                    check(visible(app,"MainDialog"),"Book list X returns to main");
                    set(app,"currentUser",user(Loma.ADMIN));
                    invoke(app,"showMain");
                    check(menu(app,"UserMenu").isEnabled(),"Admin users menu enabled");
                    check(menu(app,"LoanMenu").isEnabled(),"Admin loan menu enabled");
                    check(((JMenuItem)get(app,"menuAddBookItem")).isEnabled(),"Admin can add books");
                    menu(app,"BookMenu").getItem(1).doClick();
                    check(visible(app,"BookEditDialog"),"Add book menu opens editor");
                    close(app,"BookEditDialog");
                    check(visible(app,"BookListDialog"),"Book editor X returns to book list");
                    close(app,"BookListDialog");
                    check(visible(app,"MainDialog"),"Book list X returns to main after edit");
                    invoke(app,"showLogin");
                    check(visible(app,"LoginDialog"),"Login visible again");
                    invoke(app,"openRegister");
                    check(visible(app,"RegisterDialog"),"Registration visible");
                    close(app,"RegisterDialog");
                    check(visible(app,"LoginDialog"),"Registration X returns to login");
                    System.out.println("GUI SMOKE PASSED: "+checks+" assertions");
                } catch (Throwable ex) {
                    ex.printStackTrace();
                    System.exit(2);
                } finally {
                    try {
                        if(app!=null) {
                            for (String name:new String[]{"LoginDialog","RegisterDialog","MainDialog",
                                    "BookListDialog","BookEditDialog","UserListDialog","UserEditDialog",
                                    "LoanDialog","ReturnDialog","ReservationDialog","NotificationDialog"}) {
                                dialog(app,name).dispose();
                            }
                            app.dispose();
                        }
                    } catch(Exception ignored) { }
                }
            });
        } catch (Exception ex) { ex.printStackTrace();System.exit(2); }
        System.exit(0);
    }
}
