package bibliotekas_informacijas_sistema.dao;

import bibliotekas_informacijas_sistema.model.Lietotajs;
import bibliotekas_informacijas_sistema.model.Rezervacija;
import bibliotekas_informacijas_sistema.model.Loma;
import bibliotekas_informacijas_sistema.model.Gramata;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import bibliotekas_informacijas_sistema.db.DatabaseManager;
import static bibliotekas_informacijas_sistema.util.PasswordUtil.*;

public class RezervacijaDAO {
    private final Connection connection;

    public RezervacijaDAO() { this.connection = null; }
    RezervacijaDAO(Connection connection) { this.connection = connection; }

    public static final String STATUS_ACTIVE = "aktīva";
    public static final String STATUS_COMPLETED = "izpildīta";
    public static final String STATUS_CANCELLED = "atcelta";

    public static boolean isActiveStatus(String status) {
        if (status == null) return false;
        String s = status.trim().toLowerCase(Locale.ROOT);
        return s.equals("aktīva") || s.equals("aktiva") || s.equals("active");
    }

    private static String activeStatusPredicate() {
        return "LOWER(TRIM(statuss)) IN ('aktīva', 'aktiva', 'active')";
    }

    private static final String BASE_SELECT =
            "SELECT r.*, "
            + "u.vards AS u_vards, u.uzvards AS u_uzvards, u.lietotajvards AS u_lietotajvards, "
            + "u.parole AS u_parole, u.epasts AS u_epasts, u.loma AS u_loma, "
            + "g.nosaukums AS g_nosaukums, g.apraksts AS g_apraksts, "
            + "g.izdosanas_gads AS g_izdosanas_gads, g.isbn AS g_isbn, "
            + "g.kategorija AS g_kategorija, g.autors AS g_autors, "
            + "g.pieejamiba AS g_pieejamiba "
            + "FROM rezervacija r "
            + "LEFT JOIN lietotajs u ON u.lietotaja_id = r.lietotaja_id "
            + "LEFT JOIN gramata g ON g.gramatas_id = r.gramatas_id ";

    private void requireConnection() {
        if (connection == null) {
            throw new IllegalStateException(
                "Šī metode jāizsauc tikai ar RezervacijaDAO(Connection) konstruktoru.");
        }
    }

    private Rezervacija map(ResultSet rs) throws SQLException {
        Rezervacija value = new Rezervacija();
        value.setRezervacijasId(rs.getInt("rezervacijas_id"));
        value.setDatums(rs.getTimestamp("datums"));
        value.setStatuss(rs.getString("statuss"));

        int userId = rs.getInt("lietotaja_id");
        if (!rs.wasNull()) {
            Lietotajs u = new Lietotajs();
            u.setLietotajaId(userId);
            u.setVards(rs.getString("u_vards"));
            u.setUzvards(rs.getString("u_uzvards"));
            u.setLietotajvards(rs.getString("u_lietotajvards"));
            u.setParole(rs.getString("u_parole"));
            u.setEpasts(rs.getString("u_epasts"));
            String loma = rs.getString("u_loma");
            if (loma != null) u.setLoma(Loma.valueOf(loma));
            value.setLietotajs(u);
        }

        int bookId = rs.getInt("gramatas_id");
        if (!rs.wasNull()) {
            Gramata g = new Gramata();
            g.setGramatasId(bookId);
            g.setNosaukums(rs.getString("g_nosaukums"));
            g.setApraksts(rs.getString("g_apraksts"));
            g.setIzdosanasGads((Integer) rs.getObject("g_izdosanas_gads"));
            g.setIsbn(rs.getString("g_isbn"));
            g.setKategorija(rs.getString("g_kategorija"));
            g.setAutors(rs.getString("g_autors"));
            g.setPieejamiba(rs.getBoolean("g_pieejamiba"));
            value.setGramata(g);
        }
        return value;
    }

    private List<Rezervacija> query(String sql, Object... args) throws SQLException {
        requireConnection();
        List<Rezervacija> result = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) result.add(map(rs)); }
        }
        return result;
    }

    Rezervacija findById(int id) throws SQLException {
        List<Rezervacija> result = query(BASE_SELECT + "WHERE r.rezervacijas_id = ?", id);
        return result.isEmpty() ? null : result.get(0);
    }

    List<Rezervacija> findAll() throws SQLException {
        return query(BASE_SELECT + "ORDER BY r.rezervacijas_id");
    }

    private void bind(PreparedStatement ps, Rezervacija value) throws SQLException {
        ps.setInt(1, value.getLietotajs().getLietotajaId());
        ps.setInt(2, value.getGramata().getGramatasId());
        ps.setTimestamp(3, value.getDatums() == null
                ? null : new Timestamp(value.getDatums().getTime()));
        ps.setString(4, value.getStatuss());
    }

    int insert(Rezervacija value) throws SQLException {
        requireConnection();
        if (!connection.getAutoCommit())
            throw new SQLException("Šī metode pati pārvalda transakciju");
        int previous = connection.getTransactionIsolation();
        connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        connection.setAutoCommit(false);
        try {
            if (value.getLietotajs() == null) throw new SQLException("Nav norādīts lasītājs");
            Lietotajs user = new LietotajsDAO(connection)
                    .findById(value.getLietotajs().getLietotajaId());
            if (user == null || user.getLoma() != Loma.READER)
                throw new SQLException("Darbība atļauta tikai lasītājam");

            if (value.getGramata() == null) throw new SQLException("Nav norādīta grāmata");

            try (PreparedStatement check = connection.prepareStatement(
                    "SELECT 1 FROM rezervacija WHERE lietotaja_id = ? AND gramatas_id = ? AND "
                    + activeStatusPredicate())) {
                check.setInt(1, user.getLietotajaId());
                check.setInt(2, value.getGramata().getGramatasId());
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next()) throw new SQLException("Aktīva rezervācija jau pastāv");
                }
            }

            value.setDatums(new java.util.Date());
            value.setStatuss(STATUS_ACTIVE);

            int id;
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO rezervacija (lietotaja_id, gramatas_id, datums, statuss) "
                    + "VALUES (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                bind(ps, value);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("Nav iegūts ieraksta ID");
                    id = keys.getInt(1);
                }
            }
            connection.commit();
            value.setRezervacijasId(id);
            return id;
        } catch (SQLException | RuntimeException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
            connection.setTransactionIsolation(previous);
        }
    }

    List<Rezervacija> findActive() throws SQLException {
        return query(BASE_SELECT + "WHERE " + activeStatusPredicate()
                + " ORDER BY r.datums, r.rezervacijas_id");
    }

    List<Rezervacija> findActiveByBook(int bookId) throws SQLException {
        return query(BASE_SELECT + "WHERE r.gramatas_id = ? AND " + activeStatusPredicate()
                + " ORDER BY r.datums, r.rezervacijas_id", bookId);
    }

    boolean complete(int id) throws SQLException {
        requireConnection();
        try (PreparedStatement ps = connection.prepareStatement(
                "UPDATE rezervacija SET statuss = ? WHERE rezervacijas_id = ? AND "
                + activeStatusPredicate())) {
            ps.setString(1, STATUS_COMPLETED);
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        }
    }

    boolean update(Rezervacija value) throws SQLException {
        requireConnection();
        if (!STATUS_CANCELLED.equals(value.getStatuss()))
            throw new SQLException("Ar šo metodi rezervāciju var tikai atcelt");
        try (PreparedStatement ps = connection.prepareStatement(
                "UPDATE rezervacija SET statuss = ? WHERE rezervacijas_id = ? AND "
                + activeStatusPredicate())) {
            ps.setString(1, STATUS_CANCELLED);
            ps.setInt(2, value.getRezervacijasId());
            return ps.executeUpdate() == 1;
        }
    }

    boolean delete(int id) throws SQLException {
        requireConnection();
        try (PreparedStatement ps = connection.prepareStatement(
                "DELETE FROM rezervacija WHERE rezervacijas_id = ? AND NOT ("
                + activeStatusPredicate() + ")")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    void ensureInitialReservation(int userId, int bookId, Timestamp date, String status)
            throws SQLException {
        requireConnection();
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT 1 FROM rezervacija WHERE lietotaja_id = ? AND gramatas_id = ?")) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return; }
        }
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO rezervacija (lietotaja_id, gramatas_id, datums, statuss) "
                + "VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            ps.setTimestamp(3, date);
            ps.setString(4, status);
            ps.executeUpdate();
        }
    }

    // ============ Publiskā API ============

    @FunctionalInterface
    private interface SqlWork<T> { T run(Connection connection) throws SQLException; }

    private <T> T withConnection(SqlWork<T> work) throws SQLException {
        try (Connection c = DatabaseManager.getConnection()) {
            return work.run(c);
        }
    }

    public List<Rezervacija> findReservations(Lietotajs actor) throws SQLException {
        requireSignedIn(actor);
        if (actor.getLoma() != Loma.READER && !isStaff(actor))
            throw new SecurityException("Rezervācijas nav pieejamas šai lomai.");
        return withConnection(connection -> {
            List<Rezervacija> reservations = new RezervacijaDAO(connection).findAll();
            if (actor.getLoma() == Loma.READER) {
                reservations.removeIf(reservation -> reservation.getLietotajs() == null
                        || reservation.getLietotajs().getLietotajaId() != actor.getLietotajaId());
            }
            return reservations;
        });
    }

    public List<Gramata> findReservationBooks(Lietotajs actor) throws SQLException {
        requireReader(actor);
        return withConnection(connection -> {
            List<Gramata> books = new GramataDAO(connection).findAll();
            Set<Integer> alreadyReserved = new HashSet<>();
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT gramatas_id FROM rezervacija WHERE lietotaja_id = ? AND "
                    + activeStatusPredicate())) {
                ps.setInt(1, actor.getLietotajaId());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) alreadyReserved.add(rs.getInt(1));
                }
            }
            books.removeIf(book -> alreadyReserved.contains(book.getGramatasId()));
            return books;
        });
    }

    public void createReservation(int bookId, Lietotajs actor) throws SQLException {
        requireReader(actor);
        withConnection(connection -> {
            Gramata book = new GramataDAO(connection).findById(bookId);
            Lietotajs user = new LietotajsDAO(connection).findById(actor.getLietotajaId());
            if (book == null) throw new SQLException("Grāmata nav atrasta.");
            if (user == null || user.getLoma() != Loma.READER)
                throw new SecurityException("Rezervāciju var izveidot tikai lasītājs.");
            Rezervacija reservation = new Rezervacija();
            reservation.setGramata(book);
            reservation.setLietotajs(user);
            new RezervacijaDAO(connection).insert(reservation);
            return null;
        });
    }

    public void cancelReservation(int reservationId, Lietotajs actor) throws SQLException {
        requireReader(actor);
        withConnection(connection -> {
            RezervacijaDAO dao = new RezervacijaDAO(connection);
            Rezervacija reservation = dao.findById(reservationId);
            if (reservation == null || reservation.getLietotajs() == null
                    || reservation.getLietotajs().getLietotajaId() != actor.getLietotajaId()) {
                throw new SQLException(
                        "Rezervācija nav atrasta vai tā nepieder pašreizējam lasītājam.");
            }
            if (!RezervacijaDAO.isActiveStatus(reservation.getStatuss()))
                throw new SQLException("Atcelt var tikai aktīvu rezervāciju.");
            reservation.setStatuss(STATUS_CANCELLED);
            if (!dao.update(reservation))
                throw new SQLException("Rezervāciju neizdevās atcelt.");
            return null;
        });
    }

    public void completeReservation(int reservationId, Lietotajs actor) throws SQLException {
        requireStaff(actor);
        boolean completed = withConnection(connection ->
                new RezervacijaDAO(connection).complete(reservationId));
        if (!completed) throw new SQLException(
                "Rezervāciju nevar izpildīt. Pārbaudiet, vai tā vēl ir aktīva.");
    }

    public List<Rezervacija> findNotificationReservations(Lietotajs actor) throws SQLException {
        requireNotificationAccess(actor);
        return withConnection(c -> {
            List<Rezervacija> result = new RezervacijaDAO(c).findActive();
            if (actor.getLoma() == Loma.READER) {
                result.removeIf(v -> v.getLietotajs() == null
                        || v.getLietotajs().getLietotajaId() != actor.getLietotajaId());
            }
            return result;
        });
    }
}
